import speech_recognition as sr
from playsound import playsound
import pandas as pd
from datetime import date
from gtts import gTTS


import math
import requests

from flask import Flask, render_template,request,session,flash
import sqlite3 as sql
import os

app = Flask(__name__)
"""
@app.route("/")
def home():
    return render_template("search.html")
"""
@app.route("/")
def home():
    return render_template("index.html")

@app.route('/gohome')
def homepage():
    return render_template('index.html')

@app.route('/enternew')
def new_user():
   return render_template('signup.html')

@app.route('/addrec',methods = ['POST', 'GET'])
def addrec():
    if request.method == 'POST':
        try:
            nm = request.form['Name']
            phonno = request.form['MobileNumber']
            email = request.form['email']
            unm = request.form['Username']
            passwd = request.form['password']

            with sql.connect("genspeech.db") as con:
                cur = con.cursor()
                cur.execute("INSERT INTO genuser(name,phono,email,username,password)VALUES(?, ?, ?, ?,?)", (nm, phonno, email, unm, passwd))
                con.commit()
                msg = "Record successfully added"
        except:
            con.rollback()
            msg = "error in insert operation"

        finally:
            return render_template("result.html", result=msg)
            con.close()


@app.route('/userlogin')
def user_login():
    return render_template("login.html")

@app.route('/logindetails',methods = ['POST', 'GET'])
def logindetails():
    if request.method=='POST':
            usrname=request.form['username']
            passwd = request.form['password']

            with sql.connect("genspeech.db") as con:
                cur = con.cursor()
                cur.execute("SELECT username,password FROM genuser where username=? ",(usrname,))
                account = cur.fetchall()

                for row in account:
                    database_user = row[0]
                    database_password = row[1]
                    if database_user == usrname and database_password==passwd:
                        session['logged_in'] = True
                        return render_template('chat.html')
                    else:
                        flash("Invalid user credentials")
                        return render_template('login.html')


@app.route('/predictinfo')
def user_predict():

    r = sr.Recognizer()

    with sr.Microphone() as source:
        print("Say something")
        playsound("begin.mp3")
        audio=r.listen(source)
        ques = r.recognize_google(audio)
        lowercase=ques.lower()
        print(ques)
        data = pd.read_csv("dataset.csv")
        for i in range(len(data)):
            if data["Question"][i] ==lowercase:
                ans=data["Answer"][i]
            elif lowercase=="what is today's date":
                today_date = date.today()
                ans = today_date.strftime("%d-%b-%Y")
            elif lowercase == "what is the weather today":
                base_url = 'http://api.openweathermap.org/data/2.5/weather'
                api_key = 'ceb6f0b701baf7ddf6fec520b77ecb9b'
                city = 'Mangalore'
                query = base_url + '?q=%s&units=metric&APPID=%s' % (city, api_key)
                response = requests.get(query)
                if response.status_code != 200:
                    response = 'N/A'
                    print(response)
                else:
                    weather_data = response.json()
                    wthr=str(math.ceil(weather_data['main']['temp']))
                    ans=str(math.ceil(weather_data['main']['temp']))+"C"

            else:
                ans="unknown"

        if "which is the capital city of india" in lowercase:
            playsound("A1.mp3")
        elif "which is the capital city of karnataka" in lowercase:
            playsound("A2.mp3")
        elif "who is the current prime minister of india" in lowercase:
            playsound("A3.mp3")
        elif "who is the current president of india" in lowercase:
            playsound("A4.mp3")
        elif "who is the current vice-president of india" in lowercase:
            playsound("A5.mp3")
        elif "how many states are there in india" in lowercase:
            playsound("A6.mp3")
        elif "how many districts are there in karnataka" in lowercase:
            playsound("A7.mp3")
        elif "when did india get independence" in lowercase:
            playsound("A8.mp3")
        elif "who is the owner of facebook" in lowercase:
            playsound("A9.mp3")
        elif "who is the founder of Apple" in lowercase:
            playsound("A10.mp3")
        elif "what is a leap year" in lowercase:
            playsound("A11.mp3")
        elif "how many days are there in a leap year" in lowercase:
            playsound("A12.mp3")
        elif "who is the current captain of indian cricket team" in lowercase:
            playsound("A13.mp3")
        elif "which is the biggest continent in the world" in lowercase:
            playsound("A14.mp3")
        elif "how many continenets are there on earth" in lowercase:
            playsound("A15.mp3")
        elif "how many days are there in a year" in lowercase:
            playsound("A17.mp3")
        elif "when is mother's day" in lowercase:
            playsound("A18.mp3")
        elif "who is the ceo of google" in lowercase:
            playsound("A19.mp3")
        elif "who is the chief minister of karnataka" in lowercase:
            playsound("A20.mp3")
        elif "who is the president of america" in lowercase:
            playsound("A21.mp3")
        elif "who is the president of russia" in lowercase:
            playsound("A22.mp3")
        elif "what is fullform of USA" in lowercase:
            playsound("A23.mp3")
        elif "what is the fullform of NASA" in lowercase:
            playsound("A24.mp3")
        elif "what is the fullform of ISRO" in lowercase:
            playsound("A25.mp3")
        elif "which country has the highest population in the world" in lowercase:
            playsound("A26.mp3")
        elif "what is the population of India in 2019" in lowercase:
            playsound("A27.mp3")
        elif "which is the most popular online game in the world" in lowercase:
            playsound("A28.mp3")
        elif "which is the most played game in the world" in lowercase:
            playsound("A29.mp3")
        elif "whether 2020 is leap year" in lowercase:
            playsound("A30.mp3")
        elif "who is the author of ramayana" in lowercase:
            playsound("A31.mp3")
        elif "how many bones are present in a human body" in lowercase:
            playsound("A32.mp3")
        elif "how many stokes are present in ashoka chakra" in lowercase:
            playsound("A96.mp3")
        elif "who has invented the computer" in lowercase:
            playsound("A33.mp3")
        elif "which was the first introduced computer" in lowercase:
            playsound("A34.mp3")
        elif "who is the founder of zero" in lowercase:
            playsound("A35.mp3")
        elif "what is the fullform of VTU" in lowercase:
            playsound("A36.mp3")
        elif "which is the first satellite launched in india" in lowercase:
            playsound("A37.mp3")
        elif "who discovered radio" in lowercase:
            playsound("A38.mp3")
        elif "who discovered television" in lowercase:
            playsound("A39.mp3")
        elif "which is india's first super computer" in lowercase:
            playsound("A40.mp3")
        elif "who was the first indian travelled to space" in lowercase:
            playsound("A41.mp3")
        elif "who was the first Indian woman travelled to space" in lowercase:
            playsound("A42.mp3")
        elif "which is the largest country in the world" in lowercase:
            playsound("A43.mp3")
        elif "which is the smallest country in the world" in lowercase:
            playsound("A44.mp3")
        elif "which is the hardest substance available on earth" in lowercase:
            playsound("A45.mp3")
        elif "which is the longest river in the world" in lowercase:
            playsound("A46.mp3")
        elif "which is the largest bone in a human body" in lowercase:
            playsound("A47.mp3")
        elif "which is most southern point of india" in lowercase:
            playsound("A48.mp3")
        elif "which is the smallest continent in the world" in lowercase:
            playsound("A49.mp3")
        elif "who is the inventor of electricity" in lowercase:
            playsound("A50.mp3")
        elif "which is the largest animal in the world" in lowercase:
            playsound("A51.mp3")
        elif "who is the father of local self government" in lowercase:
            playsound("A52.mp3")
        elif "which is the minimum age limit to cast vote in india" in lowercase:
            playsound("A53.mp3")
        elif "which is the tallest waterfall in the world" in lowercase:
            playsound("A54.mp3")
        elif "which place is known as tea garden of india" in lowercase:
            playsound("A55.mp3")
        elif "which is the latest version of android" in lowercase:
            playsound("A56.mp3")
        elif "who discovered pencilin" in lowercase:
            playsound("A57.mp3")
        elif "what is the fullform of WHO" in lowercase:
            playsound("A58.mp3")
        elif "what is the fullform of WTO" in lowercase:
            playsound("A59.mp3")
        elif "what is the fulform of UNICEF" in lowercase:
            playsound("A60.mp3")
        elif "when was the atomic bomb dropped on Hiroshima and Nagasaki" in lowercase:
            playsound("A61.mp3")
        elif "how many members are there in lokasabha" in lowercase:
            playsound("A95.mp3")
        elif "what is natural language processing" in lowercase:
            playsound("A62.mp3")
        elif "which place in india has the highest rain fall" in lowercase:
            playsound("A63.mp3")
        elif "which place is known as switzerland of india" in lowercase:
            playsound("A64.mp3")
        elif "when is army day celebrated in india" in lowercase:
            playsound("A94.mp3")
        elif "what is the fullform of GATE" in lowercase:
            playsound("A65.mp3")
        elif "what is the fullform of CAT" in lowercase:
            playsound("A66.mp3")
        elif "what is the fullform of  NRC" in lowercase:
            playsound("A67.mp3")
        elif "what does the nucleus of an atom consists of" in lowercase:
            playsound("A68.mp3")
        elif "what does the ozone layer restricts" in lowercase:
            playsound("A69.mp3")
        elif "what is the fullform of DBMS" in lowercase:
            playsound("A70.mp3")
        elif "why alum is used for purifying the drinking water" in lowercase:
            playsound("A71.mp3")
        elif "which is the autobiography of Dr. A P J Abdul kalam" in lowercase:
            playsound("A72.mp3")
        elif "which state has the highest liteacy rate in india" in lowercase:
            playsound("A73.mp3")
        elif "who is called as the missile man of india" in lowercase:
            playsound("A74.mp3")
        elif "who is the author of indian national anthem" in lowercase:
            playsound("A75.mp3")
        elif "what does the nucleus of a hydrogen atom consists of" in lowercase:
            playsound("A76.mp3")
        elif "what is the boiling point of water" in lowercase:
            playsound("A77.mp3")
        elif "which is the bacteiria present in milk" in lowercase:
            playsound("A78.mp3")
        elif "which is the largest desert in the world" in lowercase:
            playsound("A79.mp3")
        elif "where will be the next olympic games held" in lowercase:
            playsound("A80.mp3")
        elif "which is the national game of india" in lowercase:
            playsound("A81.mp3")
        elif "what is the total number of national parks in karnataka" in lowercase:
            playsound("A82.mp3")
        elif "who is known as the father of karnataka music" in lowercase:
            playsound("A83.mp3")
        elif "which sea is to the west of karnataka" in lowercase:
            playsound("A84.mp3")
        elif "who is the first president of india" in lowercase:
            playsound("A85.mp3")
        elif "which is largest river in karnataka" in lowercase:
            playsound("A86.mp3")
        elif "who invented gravity" in lowercase:
            playsound("A87.mp3")
        elif "who is the father of indian constitution" in lowercase:
            playsound("A88.mp3")
        elif "when were bar code scanners invented" in lowercase:
            playsound("A89.mp3")
        elif "who is the present chief of indian army" in lowercase:
            playsound("A90.mp3")
        elif "which is the first satellite launched in the world" in lowercase:
            playsound("A91.mp3")
        elif "which is the tallest mountain in the world" in lowercase:
            playsound("A92.mp3")
        elif "which country has the largest democracy in the world" in lowercase:
            playsound("A93.mp3")
        elif "which country has the largest constitution in the world" in lowercase:
            playsound("A93.mp3")
        elif "what is today's date" in lowercase:
            today_date = date.today()
            answr = today_date.strftime("%d-%b-%Y")
            today1 = gTTS(text=answr, lang='en-in')
            today1.save("A97.mp3")
            playsound("A97.mp3")
        elif "what is the weather today" in lowercase:
            weather=wthr +"degree celcius"
            weather1=gTTS(text=weather, lang='en-in')
            weather1.save("A98.mp3")
            playsound("A98.mp3")
        else:
            playsound('unknown.mp3')

        return render_template('chat.html',ques=lowercase,ans=ans)

@app.route("/logout")
def logout():
    session['logged_in'] = False
    return render_template('login.html')

if __name__ == '__main__':
    app.secret_key = os.urandom(12)
    app.run(debug=True)







