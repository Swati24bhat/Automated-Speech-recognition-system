

from gtts import gTTS
"""
unknw="unknown"
unknw1=gTTS(text=unknw,lang='en-in')
unknw1.save("unknown.mp3")


savtxtb = "Hi, How can I help you?"
speechb = gTTS(text=savtxtb, lang='en-in', slow=False)
speechb.save("begin.mp3")

savtxt1 = "new delhi"
speech1 = gTTS(text=savtxt1, lang='en-in')
speech1.save("A1.mp3")

savtxt2 = "bangalore"
speech2 = gTTS(text=savtxt2, lang='en-in')
speech2.save("A2.mp3")

savtxt3 = "the prime minister of India is mr. narendra modi"
speech3 = gTTS(text=savtxt3, lang='en-in')
speech3.save("A3.mp3")

savtxt4 = "the president of India is mr. ramnath kovind"
speech4 = gTTS(text=savtxt4, lang='en-in')
speech4.save("A4.mp3")

savtxt5 = "the current vice president of india is mr. venkaiah naidu"
speech5 = gTTS(text=savtxt5, lang='en-in')
speech5.save("A5.mp3")

savtxt6 = "total number of states in india is 29"
speech6 = gTTS(text=savtxt6, lang='en-in')
speech6.save("A6.mp3")

savtxt7 = "Total number of districts in Karnataka is 30"
speech7 = gTTS(text=savtxt7, lang='en-in')
speech7.save("A7.mp3")

savtxt8 = "India got independence in 1947"
speech8 = gTTS(text=savtxt8, lang='en-in')
speech8.save("A8.mp3")

savtxt9 = "the owner of facebook is mark zuckerberg"
speech9 = gTTS(text=savtxt9, lang='en-in')
speech9.save("A9.mp3")

savtxt10 = "the founders of apple are steve jobs, steve wozniak and ronald wayne"
speech10 = gTTS(text=savtxt10, lang='en-in')
speech10.save("A10.mp3")

savtxt11 = "leap year is a year occuring once in every four years, which has 366 days including 29 february as an intercalary day"
speech11 = gTTS(text=savtxt11, lang='en-in')
speech11.save("A11.mp3")

savtxt12 = "366 days"
speech12 = gTTS(text=savtxt12, lang='en-in')
speech12.save("A12.mp3")

savtxt13 = "the captain of Indian cricket is virat kohli"
speech13 = gTTS(text=savtxt13, lang='en-in')
speech13.save("A13.mp3")

savtxt14 = "the biggest continent is Asia"
speech14 = gTTS(text=savtxt14, lang='en-in')
speech14.save("A14.mp3")

savtxt15 = "7"
speech15 = gTTS(text=savtxt15, lang='en-in')
speech15.save("A15.mp3")


savtxt17 = "there are 365 days in a year"
speech17 = gTTS(text=savtxt17, lang='en-in')
speech17.save("A17.mp3")

savtxt18 = "sunday of 10th may, 2020"
speech18 = gTTS(text=savtxt18, lang='en-in')
speech18.save("A18.mp3")

savtxt19 = "ceo of google is mr.sundar pichai"
speech19 = gTTS(text=savtxt19, lang='en-in')
speech19.save("A19.mp3")

savtxt20 = "the chief minister of karnataka is mr.yadiyoorappa"
speech20 = gTTS(text=savtxt20, lang='en-in')
speech20.save("A20.mp3")

savtxt21 = "the president of america is mr.donald trumph"
speech21 = gTTS(text=savtxt21, lang='en-in')
speech21.save("A21.mp3")

savtxt22 = "the president of russia is mr.vladiminar putin"
speech22 = gTTS(text=savtxt22, lang='en-in')
speech22.save("A22.mp3")

savtxt23 = "united states of america"
speech23 = gTTS(text=savtxt23, lang='en-in')
speech23.save("A23.mp3")

savtxt24 = "national aeronautics and space administration"
speech24 = gTTS(text=savtxt24, lang='en-in')
speech24.save("A24.mp3")

savtxt25 = "indian space research organization"
speech25 = gTTS(text=savtxt25, lang='en-in')
speech25.save("A25.mp3")

savtxt26 = "china"
speech26 = gTTS(text=savtxt26, lang='en-in')
speech26.save("A26.mp3")

savtxt27 = "the population of india in 2019 is 1.37 billion"
speech27 = gTTS(text=savtxt27, lang='en-in')
speech27.save("A27.mp3")

savtxt28 = "the most popular game in the world is pubg"
speech28 = gTTS(text=savtxt28, lang='en-in')
speech28.save("A28.mp3")

savtxt29 = "the most played game in the world is soccer"
speech29 = gTTS(text=savtxt29, lang='en-in')
speech29.save("A29.mp3")

savtxt30 = " yes, 2020 is a leap year"
speech30 = gTTS(text=savtxt30, lang='en-in')
speech30.save("A30.mp3")

savtxt31 = "valmiki is the author of ramayana"
speech31 = gTTS(text=savtxt31, lang='en-in')
speech31.save("A31.mp3")

savtxt32 = "the total number of bones present in humn body is 206"
speech32 = gTTS(text=savtxt32, lang='en-in')
speech32.save("A32.mp3")

savtxt33 = "charles babbage"
speech33 = gTTS(text=savtxt33, lang='en-in')
speech33.save("A33.mp3")

savtxt34 = "abacus"
speech34 = gTTS(text=savtxt34, lang='en-in')
speech34.save("A34.mp3")

savtxt35 = "aryabhata"
speech35 = gTTS(text=savtxt35, lang='en-in')
speech35.save("A35.mp3")

savtxt36 = "visvesvaraya technological university"
speech36 = gTTS(text=savtxt36, lang='en-in')
speech36.save("A36.mp3")

savtxt37 = "guglielmo marconi"
speech37 = gTTS(text=savtxt37, lang='en-in')
speech37.save("A37.mp3")

savtxt38 = "john logic baird"
speech38 = gTTS(text=savtxt38, lang='en-in')
speech38.save("A38.mp3")

savtxt39 = "param 8000"
speech39 = gTTS(text=savtxt39, lang='en-in')
speech39.save("A39.mp3")

savtxt40 = "pilot rakesh sharma"
speech40 = gTTS(text=savtxt40, lang='en-in')
speech40.save("A40.mp3")

savtxt41 = "kalpana chavla"
speech41 = gTTS(text=savtxt41, lang='en-in')
speech41.save("A41.mp3")

savtxt42 = "russia"
speech42 = gTTS(text=savtxt42, lang='en-in')
speech42.save("A42.mp3")

savtxt43 = "vatican city"
speech43 = gTTS(text=savtxt43, lang='en-in')
speech43.save("A43.mp3")

savtxt44 = "diamond"
speech44 = gTTS(text=savtxt44, lang='en-in')
speech44.save("A44.mp3")

savtxt45 = "the nile is the longest river in the world"
speech45 = gTTS(text=savtxt45, lang='en-in')
speech45.save("A43.mp3")

savtxt46 = "thigh bone is the largest bone in human's body"
speech46 = gTTS(text=savtxt46, lang='en-in')
speech46.save("A46.mp3")

savtxt47 = "indira point"
speech47 = gTTS(text=savtxt47, lang='en-in')
speech47.save("A47.mp3")

savtxt48 = "australia is the smallest continent in the world"
speech48 = gTTS(text=savtxt48, lang='en-in')
speech48.save("A48.mp3")

savtxt49 = "benjamin franklin is the inventor of electricity"
speech49 = gTTS(text=savtxt49, lang='en-in')
speech49.save("A49.mp3")

savtxt50 = "blue whale is the largest animal in the world"
speech50 = gTTS(text=savtxt50, lang='en-in')
speech50.save("A50.mp3")

savtxt51 = "lord ripon is the father of local self government"
speech51 = gTTS(text=savtxt51, lang='en-in')
speech51.save("A51.mp3")

savtxt52 = "18 years is the minimum age limit to cast vote in india"
speech52 = gTTS(text=savtxt52, lang='en-in')
speech52.save("A52.mp3")

savtxt53 = "angel falls is the tallest waterfall in the world"
speech53 = gTTS(text=savtxt53, lang='en-in')
speech53.save("A53.mp3")

savtxt54 = "darjeeling is known as the tea garden of india"
speech54 = gTTS(text=savtxt54, lang='en-in')
speech54.save("A54.mp3")

savtxt55 = "android 10.0"
speech55 = gTTS(text=savtxt55, lang='en-in')
speech55.save("A55.mp3")

savtxt56 = "alexander fleming"
speech56 = gTTS(text=savtxt56, lang='en-in')
speech56.save("A56.mp3")

savtxt57 = "world health organization"
speech57 = gTTS(text=savtxt57, lang='en-in')
speech57.save("A57.mp3")

savtxt58 = "world trade organization"
speech58 = gTTS(text=savtxt58, lang='en-in')
speech58.save("A58.mp3")

savtxt59 = "united nations international children's emergency fund"
speech59 = gTTS(text=savtxt59, lang='en-in')
speech59.save("A59.mp3")

savtxt60 = "august 6th and 9th of 1945"
speech60 = gTTS(text=savtxt60, lang='en-in')
speech60.save("A60.mp3")

savtxt61 = "facebook"
speech61 = gTTS(text=savtxt61, lang='en-in')
speech61.save("A61.mp3")

savtxt62 = "it is a field of artificial intelligence concerned with the interactions between computers and human languag"
speech62 = gTTS(text=savtxt62, lang='en-in')
speech62.save("A62.mp3")

savtxt63 = "mawsynram in meghalaya"
speech63 = gTTS(text=savtxt63, lang='en-in')
speech63.save("A63.mp3")

savtxt64 = "khajjiar"
speech64 = gTTS(text=savtxt64, lang='en-in')
speech64.save("A64.mp3")

savtxt65 = "graduate aptitude test in engineering"
speech65 = gTTS(text=savtxt65, lang='en-in')
speech65.save("A65.mp3")

savtxt66 = "common admission test"
speech66 = gTTS(text=savtxt66, lang='en-in')
speech66.save("A66.mp3")

savtxt67 = "national register of citizens"
speech67 = gTTS(text=savtxt67, lang='en-in')
speech67.save("A67.mp3")

savtxt68 = "the nucleus of an atom consists of neutrons and protons"
speech68 = gTTS(text=savtxt68, lang='en-in')
speech68.save("A68.mp3")

savtxt69 = "the ozone layer restricts ultraviolet radiations"
speech69 = gTTS(text=savtxt69, lang='en-in')
speech69.save("A69.mp3")

savtxt70 = "database management system"
speech70 = gTTS(text=savtxt70, lang='en-in')
speech70.save("A70.mp3")

savtxt71 = "alum is used in purification of drinking water to form gelatinous precipitate"
speech71 = gTTS(text=savtxt71, lang='en-in')
speech71.save("A71.mp3")

savtxt72 = "wings of fire"
speech72 = gTTS(text=savtxt72, lang='en-in')
speech72.save("A72.mp3")

savtxt73 = "kerala"
speech73 = gTTS(text=savtxt73, lang='en-in')
speech73.save("A73.mp3")

savtxt74 = "dr.a p j abdul kalam"
speech74 = gTTS(text=savtxt74, lang='en-in')
speech74.save("A74.mp3")

savtxt75 = "ravindranath tagore"
speech75 = gTTS(text=savtxt75, lang='en-in')
speech75.save("A75.mp3")

savtxt76 = "the nucleus of a hydrogen atom consists of a single proton"
speech76 = gTTS(text=savtxt76, lang='en-in')
speech76.save("A76.mp3")

savtxt77 = "100 degree celsius"
speech77 = gTTS(text=savtxt77, lang='en-in')
speech77.save("A77.mp3")

savtxt78 = "lactobacilli"
speech78 = gTTS(text=savtxt78, lang='en-in')
speech78.save("A78.mp3")

savtxt79 = "sahara desert"
speech79 = gTTS(text=savtxt79, lang='en-in')
speech79.save("A79.mp3")

savtxt80 = "tokyo, japan"
speech80 = gTTS(text=savtxt80, lang='en-in')
speech80.save("A80.mp3")

savtxt81 = "hockey is the national game of india"
speech81 = gTTS(text=savtxt81, lang='en-in')
speech81.save("A81.mp3")

savtxt82 = "total number of national parks in karnataka is 5"
speech82 = gTTS(text=savtxt82, lang='en-in')
speech82.save("A82.mp3")

savtxt83 = "purandara dasa is known as the father of karnataka music"
speech83 = gTTS(text=savtxt83, lang='en-in')
speech83.save("A83.mp3")

savtxt84 = "arabian sea"
speech84 = gTTS(text=savtxt84, lang='en-in')
speech84.save("A84.mp3")

savtxt85 = "rajendra prasad"
speech85 = gTTS(text=savtxt85, lang='en-in')
speech85.save("A85.mp3")

savtxt86 = "kaveri is the largest river in karnataka"
speech86 = gTTS(text=savtxt86, lang='en-in')
speech86.save("A86.mp3")

savtxt87 = "sir isaac newton"
speech87 = gTTS(text=savtxt87, lang='en-in')
speech87.save("A87.mp3")

savtxt88 = "dr.b r ambedkar"
speech88 = gTTS(text=savtxt88, lang='en-in')
speech88.save("A88.mp3")

savtxt89 = "bar code scanners were invented in 1951"
speech89 = gTTS(text=savtxt89, lang='en-in')
speech89.save("A89.mp3")

savtxt90 = "hemanth singh"
speech90 = gTTS(text=savtxt90, lang='en-in')
speech90.save("A90.mp3")

savtxt91 = "sputnik 1"
speech91 = gTTS(text=savtxt91, lang='en-in')
speech91.save("A91.mp3")

savtxt92 = "mount everest"
speech92 = gTTS(text=savtxt92, lang='en-in')
speech92.save("A92.mp3")

savtxt93 = "india"
speech93 = gTTS(text=savtxt93, lang='en-in')
speech93.save("A93.mp3")
"""
savtxt94 = "January 15"
speech94 = gTTS(text=savtxt94, lang='en-in')
speech94.save("A94.mp3")
"""
savtxt95 = "552"
speech95 = gTTS(text=savtxt95, lang='en-in')
speech95.save("A95.mp3")

savtxt96 = "24"
speech96 = gTTS(text=savtxt96, lang='en-in')
speech96.save("A96.mp3")

"""











